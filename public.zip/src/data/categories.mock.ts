export const mockCategories = [
  {
    category_id: 1,
    name: "Vitaminas",
    description: "Vitaminas y minerales esenciales",
  },
  {
    category_id: 2,
    name: "Creatina y Aminoácidos",
    description: "Fuerza y recuperación",
  },
  {
    category_id: 3,
    name: "Proteínas",
    description: "Proteínas vegetales y animales",
  },
  {
    category_id: 4,
    name: "Pre-entrenos",
    description: "Energía antes del entrenamiento",
  },
  {
    category_id: 5,
    name: "Ácidos grasos",
    description: "Omega 3, 6 y suplementos de aceites",
  },
  {
    category_id: 6,
    name: "Snacks",
    description: "Barritas y comidas deportivas",
  },
  {
    category_id: 7,
    name: "Accesorios",
    description: "Shakers, botellas y accesorios",
  },
];
