export default function Checkout() {
  return (
    <section className="space-y-2">
      <h1 className="text-2xl font-semibold">Checkout</h1>
      <p className="opacity-80">Dirección, envío, método de pago y confirmación.</p>
    </section>
  );
}
