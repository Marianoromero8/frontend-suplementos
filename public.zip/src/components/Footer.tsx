export default function Footer() {
  return (
    <div className="flex justify-center p-10 ">
      © 2025 - Suplementos Deportivos
    </div>
  );
}
